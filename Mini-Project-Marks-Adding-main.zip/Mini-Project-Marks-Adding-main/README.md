# Mini-Project - Marks Adding

- Explore **"Mini Project - Marks Adding.pdf"** for full assignment


<img src="https://github.com/psrana/Mini-Project-Marks-Adding/assets/7460892/9be14aa0-eaa0-403a-9575-32771724f0e2" width="60%" height="80%" />
